#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup()
{
	ofSetVerticalSync(true);

	int num = 1500;
	p.assign(num, Particle());
	currentMode = PARTICLE_MODE_ATTRACT;
	currentSize = 1;
	currentSpeed = 1;
	isRecording = false;
	Playback = false;

	currentModeStr = "1 - PARTICLE_MODE_ATTRACT: attracts to mouse";

	resetParticles();
}

//--------------------------------------------------------------
void ofApp::resetParticles()
{

	//these are the attraction points used in the fourth demo
	attractPoints.clear();
	for (int i = 0; i < 4; i++)
	{
		attractPoints.push_back(glm::vec3(ofMap(i, 0, 4, 100, ofGetWidth() - 100), ofRandom(100, ofGetHeight() - 100), 0));
	}

	attractPointsWithMovement = attractPoints;

	for (unsigned int i = 0; i < p.size(); i++)
	{
		p[i].setMode(currentMode);
		p[i].setAttractPoints(&attractPointsWithMovement);
		p[i].reset();
		p[i].setScale(p[i].getScale()*currentSize);
		p[i].setVelocity(p[i].getVelocity() * currentSpeed);
	}
}

//--------------------------------------------------------------
void ofApp::update()
{
	float timer = (60 * 5);
	for (unsigned int i = 0; i < p.size(); i++)
	{
		p[i].setMode(currentMode);
		p[i].update();
	}

	//lets add a bit of movement to the attract points
	for (unsigned int i = 0; i < attractPointsWithMovement.size(); i++)
	{
		attractPointsWithMovement[i].x = attractPoints[i].x + ofSignedNoise(i * 10, ofGetElapsedTimef() * 0.7) * 12.0;
		attractPointsWithMovement[i].y = attractPoints[i].y + ofSignedNoise(i * -10, ofGetElapsedTimef() * 0.7) * 12.0;
	}
	if (Playback == true)
	{
		if(timer < 300)
		{
			timer++;
		}
		if (timer == 300)
		{
			
			
			timer = 1;
		}
	}
}

//--------------------------------------------------------------
void ofApp::draw()
{
	ofBackgroundGradient(ofColor(90, 10, 100), ofColor(80, 70, 150));

	for (unsigned int i = 0; i < p.size(); i++)
	{
		p[i].draw();
	}

	ofSetColor(190);
	if (currentMode == PARTICLE_MODE_NEAREST_POINTS)
	{
		for (unsigned int i = 0; i < attractPoints.size(); i++)
		{
			ofNoFill();
			ofDrawCircle(attractPointsWithMovement[i], 10);
			ofFill();
			ofDrawCircle(attractPointsWithMovement[i], 4);
		}
	}

	ofSetColor(230);
	ofDrawBitmapString(currentModeStr + "\n\nSpacebar to reset. \nKeys 1-4 to change mode.", 10, 20);

	if (isRecording == true)
	{
		ofSetColor(255,0,0);
		ofDrawCircle(250,20,10);
		
	}
	if (currentMode == PARTICLE_MODE_EASTER_EGG)
	{
		ofSetColor(236, 152, 63);
		ofDrawCircle(500, 500, 250);
		ofSetColor(0, 0, 0);
		ofDrawCircle(600, 400, 20);
		ofSetColor(0, 0, 0);
		ofDrawCircle(400, 400, 20);
		ofSetColor(0, 0, 0);
		ofDrawTriangle(510, 490, 490, 500, 510, 510);
		ofSetColor(0, 0, 0);
		ofDrawRectangle(450, 650, 100, 10);

	}
	
		

	
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key)
{
	if (key == '1')
	{
		
		if (isRecording == true)
		{
			inputs += "1";
		}	
		else
		{
			currentMode = PARTICLE_MODE_ATTRACT;
			currentModeStr = "1 - PARTICLE_MODE_ATTRACT: attracts to mouse";
		}
	}
	if (key == '2')
	{
		if(isRecording == true)
		{
			inputs += '2';
		}
		else
		{
			currentMode = PARTICLE_MODE_REPEL;
			currentModeStr = "2 - PARTICLE_MODE_REPEL: repels from mouse";
		}
	}
	if (key == '3')
	{
		if(isRecording)
		{
			inputs +='3';
		}
		else
		{
		currentMode = PARTICLE_MODE_NEAREST_POINTS;
		currentModeStr = "3 - PARTICLE_MODE_NEAREST_POINTS:";
		}
	}
	if (key == '4')
	{
		if(isRecording)
		{
			inputs += '4';
		}
		else
		{
		currentMode = PARTICLE_MODE_NOISE;
		currentModeStr = "4 - PARTICLE_MODE_NOISE: snow particle simulation";
		resetParticles();
		}
	}

	if (key == ' ')
	{
		if (isRecording)
		{
			inputs += ' ';
		}
		else{
		resetParticles();
		}
	}
	if (key == 'i' || key == 'I')
	{
		if(isRecording)
		{
			inputs += 'i';
		}
		else
		{
		currentSize *= 3;
		resetParticles();
		}
	}
	if (key == 'd' || key == 'D')
	{
		if(isRecording)
		{
			inputs += 'd';
		}
		else
		{
			currentSize /= 3;
			resetParticles();
			if (currentSize <=0)
			{
				currentModeStr = "You have Excecuted Order 66";
				resetParticles();
			}
			else
			{
				resetParticles();
			}
		}
	}
	if (key == 'f'|| key == 'F')
	{
		if(isRecording)
		{
			inputs += 'f';
		}
		else
		{
		currentSpeed *= 4;
		currentModeStr = "Thank You For paying your respects!";
		resetParticles();
		}
	}
	if (key == 's'|| key == 'S')
	{
		if(isRecording)
		{
			inputs += 's';
		}
		else{
		currentSpeed /= 4;
		resetParticles();
		}
	}
	if (key == 'a'|| key == 'A')
	{
		if(isRecording)
		{
			inputs += 'a';
		}
		else
		{
		currentMode = PARTICLE_MODE_PAUSE;
		currentModeStr = "The Particles are paused";
		}
	}
	if (key == 'r'|| key == 'R')
	{
		isRecording = true;
		currentModeStr = "The Program is now Recording" "\nPress t to finish recording";
		
	}
	if (key == 't'|| key == 'T')
	{
	
		isRecording = false;
		currentModeStr = "Finished Recording";
		
	}
	if (key == 'p'|| key == 'P')
	{
		Playback  = true;
		currentModeStr = "Playing back: " + inputs + "\nPress 'c' to clear";
			

	}
	if (key == 'c'|| key == 'C')
	{
		Playback = false;
		currentSize = 1;
		currentSpeed = 1;
		inputs = " ";
		currentModeStr = "Cleared Screen";
		currentMode =  PARTICLE_MODE_ATTRACT;
		resetParticles();
	}
	if (key == 'q'|| key == 'Q')
	{
		currentMode = PARTICLE_MODE_EASTER_EGG;
		currentSize /= 1000;
		currentModeStr = "Well, this is awkward, why are you pressing random keys?" 
		"\nWell no matter as long if you dont press the '*', then you will be fine";
		resetParticles();
	}
	if (key == '*') //This is for the person reviewing this code... Im sorry that i did this XD. It was just a funny joke XD
	//Remember to drink plenty of water as well :v
	{
		currentMode = PARTICLE_MODE_WTF;
		currentModeStr = "WHAT HAVE YOU DONE"
		"\nYou have Unleashed the beast of what is the metroid wikipedia!!! Here it comes!"
		"\nMetroid follows the adventures of bounty hunter Samus Aran, who battles the villainous Space Pirates. The pirates threaten the Galactic Federation with their attempts to harness biological weapons such as the parasitic Metroid creatures" 
		"\nand the hazardous Phazon material. Samus was raised by the Chozo, an avian race, after her parents were killed by Space Pirates. She serves in the military of the Galactic Federation before departing and beginning work as a bounty hunter"
		"\nIn the original Metroid, Samus travels to the planet Zebes to stop the Space Pirates from using the Metroids to create biological weapons. She defeats the cybernetic lifeform Mother Brain, as well as its guardians, Kraid and Ridley."
		"\nIn Metroid II, Samus travels to the Metroid homeworld, SR388, to exterminate the species, but saves a hatchling Metroid that bonds to her and delivers it to the Ceres research station for study. In Super Metroid, Ridley steals the"
		"\nhatchling and takes it to Zebes, where the Space Pirates are attempting to clone the Metroids. Samus is nearly killed by Mother Brain, but is rescued by the Metroid, now grown. Samus escapes as Zebes explodes."
		"\nIn Metroid Fusion, Samus investigate a space station in orbit around SR388 swarming with organisms infected with shapeshifting creatures known as X parasites.A vaccine made from the baby Metroid's cells saves her life. She"
		"\ndiscovers that the Federation has been cloning Metroids in secret, and sets the space station on a collision with SR388 to destroy it. In Metroid: Other M, set before Metroid Fusion, Samus investigates a derelict space"
		"\nstation with a Galactic Federation platoon. They team up to stop a clone of Mother Brain created by a Federation group. The Metroid Prime series is set between Metroid and Metroid II. In Metroid Prime, Samus travels to Tallon IV"
		"\nto stop the Space Pirates from exploiting a powerful radioactive substance, Phazon. Metroid Prime: Hunters sees Samus respond to a distress call to the Alimbic Cluster, and fights alongside other bounty hunters against a creature named"
		"\nGorea. In Metroid Prime 2: Echoes, Samus explores the planet Aether, which has been split into 'light' and 'dark' dimensions, and battles Dark Samus and the Ing race. In Metroid Prime 3: Corruption, Samus searches for bounty hunters who"
		"\nhave been infected with Phazon, while being slowly corrupted by Phazon herself. Metroid Prime: Federation Force, the only game in which players do not control Samus, sees Samus mind-controlled by Space Pirates; the Federation Force"
		"\nbattles to rescue her and destroy the Space Pirates. Metroid[a] is a Japanese action-adventure game franchise created by Nintendo. The player controls bounty hunter Samus Aran, who protects the galaxy from the Space Pirates and their"
		"\nattempts to harness the power of the parasitic Metroid creatures. The first Metroid was developed by Nintendo R&D1 and released on the Nintendo Entertainment System in 1986. It was followed by Metroid II: Return of Samus (1991) for the"
		"\nhandheld Game Boy and Super Metroid (1994) for the Super Nintendo Entertainment System. After a hiatus, Metroid Fusion (2002) and Metroid: Zero Mission (2004) were released for the Game Boy Advance. The first 3D Metroid game, Metroid Prime"
		"\n(2002), was developed by Retro Studios for the GameCube, followed by Metroid Prime 2: Echoes (2004) and the Wii game Metroid Prime 3: Corruption (2007). Metroid: Other M (2010), developed by Team Ninja for the Wii, received weaker reviews."
		"\nAfter another hiatus, developer Mercury Steam helmed the return of 2D Metroid with Metroid: Samus Returns (2017) for the handheld Nintendo DS, followed by Metroid Dread (2021) for the Nintendo Switch. Metroid combines the platforming of"
		"\nSuper Mario Bros. and the exploration of The Legend of Zelda with a science fiction setting and an emphasis on nonlinear gameplay. Players battle hostile alien enemies and obtain power-ups as they progress through the game world. The series"
		"\nis known for its isolated atmosphere, featuring few non-player characters. Most Metroid games are side-scrolling, while the Prime games adopt a first-person perspective. As of September 2012, the Metroid series had sold over 17.44 million"
		"\n copies.[2] Metroid games are often ranked among the greatest of all time. The series has been represented in other Nintendo media, including the Super Smash Bros. series. Additional media includes soundtracks, comic books, and manga."
		"\nAlong with the 1997 Konami game Castlevania: Symphony of the Night, the early Metroid games defined the Metroidvania subgenre, inspiring other games with continuous, explorable side-scrolling levels. Samus was one of the first prominent"
		"\nfemale video game characters.The central figures in the production and development of the Metroid series are Satoru Okada, who directed Metroid and created the series; Yoshio Sakamoto, who acted as a character designer for the first game"
		"\nand has directed or supervised the development of most of the subsequent games; Gunpei Yokoi, who headed the R&D1 division and produced the first two games; Makoto Kano, who wrote the scenario for Metroid, co-designed the second game, and"
		"\nproduced the third; and Hiroji Kiyotake, who designed characters for the original game.[3] The original Metroid, an action game for the Family Computer Disk System, was developed by Nintendo's Research and Development 1 (R&D1) and released"
		"\nin Japan on August 6, 1986.[4] It was published for the Nintendo Entertainment System in August 1987 in North America and on January 15, 1988, in Europe.[5][6] It was directed by Satoru Okada.[3] Metroid was designed to be a shooting game"
		"\nthat combined the platform jumping of Super Mario Bros. with the non-linear exploration of The Legend of Zelda and a darker aesthetic. The name of the game is a portmanteau of the words 'metro' (as in rapid transit) and android, and was"
		"\nmeant to allude to the mainly underground setting of the first game as well as its robot-like protagonist.[7] Halfway through development of the original Metroid, one of the staff said to his fellow developers 'Hey, wouldn't that be kind of"
		"\ncool if it turned out that this person inside the suit was a woman?', and the idea was accepted.[3][8] Ridley Scott's 1979 science-fiction horror film Alien was described by Sakamoto as a 'huge influence' after the world of the first Metroid"
		"\nhad been created. In recognition of this, a main antagonist was given the name Ridley, after director Ridley Scott. The development staff were also influenced by the work of the film's creature designer H. R. Giger, finding his style to be"
		"\nfitting for the Metroid universe.[9] Metroid II: Return of Samus was released for the Game Boy in 1991 in North America and in 1992 in Japan. Metroid II also further established Samus' visual design, with the bulky Varia Suit upgrade and"
		"\ndifferent arm cannons.[4] As R&D1 were committed to making another game, Nintendo brought in Intelligent Systems to develop Super Metroid for the Super Nintendo Entertainment System (SNES).[10] Super Metroid drastically expanded the"
		"\nMetroid formula, with numerous new power-ups[11] and a richer story.[12] It was released to critical acclaim and is considered one of the best SNES games.[3] It was directed by Yoshio Sakamoto, character designer for the first Metroid;"
		"\nSakamoto has directed or produced most of the 2D Metroid games since.[3] In 2002, Nintendo released Metroid Fusion, a 2D game for the Game Boy Advance (GBA).[3] It was developed by R&D1 and written and directed by Sakamoto.[13] Its"
		"\ngameplay is similar to that of Super Metroid,[14] but with a more mission-based structure that gives more guidance to the player.[15] The team's next GBA project was Zero Mission (2004), a remake of the original Metroid.[3] Both GBA games"
		"\nreceived acclaim.[16][17] A Nintendo restructure merged R&D1 with R&D2 in 2003, shortly ahead of the release of Zero Mission.[18] A 2D Metroid game for the DS, Metroid Dread was in development around 2006, but this version was never released."
		"\nUntil october 8, 2021, A new Metroid game has realeased and its called metroid dread. Nintendo considered developing a Metroid game for the Nintendo 64, but could not generate concrete ideas;[19] Sakamoto said: 'When I held the N64 controller"
		"\nin my hands I just couldn't imagine how it could be used to move Samus around.'[20] An unidentified company declined an offer from Nintendo to develop an N64 Metroid, but they turned it down, saying they were not confident they could create a"
		"\nworthwhile successor to Super Metroid.[20] Samus first appeared in 3D in the N64 fighting game Super Smash Bros. (1999).[21] In 2000, Nintendo producer Shigeru Miyamoto visited the new Nintendo subsidiary Retro Studios in Austin, Texas and"
		"\ntasked Retro with developing a Metroid game for their new console, the GameCube.[22][23] Metroid Prime, the first 3D Metroid game, moved the nonlinear structure of Super Metroid to a first-person perspective;[24] Nintendo stressed that it was"
		"\nnot a first-person shooter but a 'first-person adventure'.[3] Metroid Prime 2: Echoes (2004) saw Samus switching between parallel light and dark worlds, and introduced more difficulty.[24] Metroid Prime 3: Corruption, released for Wii in 2007"
		"\nadded motion controls[3] and has Samus exploring separate planets, with more emphasis on shooting action.[24] The Prime games were rereleased for Wii in the compilation Metroid Prime Trilogy.[25] In 2005, Nintendo released Metroid Prime Pinball"
		"\na pinball spin-off, for the handheld Nintendo DS.[26] Metroid Prime Hunters, a multiplayer game developed by Nintendo Software Technology, was released for DS in 2006.[3] A new 3D Metroid game, Metroid: Other M, developed with Japanese studio"
		"\nTeam Ninja and directed by Sakamoto, was released for Wii on August 31, 2010.[27] It returned to a third-person perspective and placed a greater focus on story and action. Other M received weaker reviews, with criticism for its characterization"
		"\nof Samus as timid and emotional and its reduced emphasis on exploration.[28] Polygon described Other M as 'such a massive misfire and a flop with fans that it practically killed the series', with no major new Metroid games in the following decade."
		"\n[29] The franchise was represented by a minigame, 'Metroid Blast,' in the Wii U game Nintendo Land (2012), which had a mixed reception.[30] The player using the Wii U GamePad controls Samus' Gunship, while up to four players with Wii Remotes and"
		"\nNunchuks control Mii characters on foot, wearing Varia Suits. Miyamoto said this reflected his ideas for future Metroid games.[31] In 2014, a former artist from Next Level Games said that Next Level had built a 3DS Metroid prototype before"
		"\nNintendo asked them to develop Luigi's Mansion: Dark Moon instead.[32] In 2016, Nintendo released Metroid Prime: Federation Force, a multiplayer game for the 3DS developed by Next Level Games. It received criticism for its multiplayer focus and"
		"\nfrivolous tone.[33] In 2017, Nintendo released a remake of Metroid II for the 3DS, Metroid: Samus Returns, developed by MercurySteam and Nintendo EPD.[34] It retained the side-scrolling gameplay of the original, adding 3D graphics and new gameplay"
		"\nfeatures such as melee combat.[35][36] At E3 2017, Nintendo announced Metroid Prime 4 for the Nintendo Switch.[37] According to Eurogamer, it was initially developed by Bandai Namco Studios, but Nintendo was not satisfied with its progress.[38] In"
		"\n2019, development restarted under Retro Studios, developer of the previous Metroid Prime games.[39] On October 8, 2021, Nintendo released a new 2D Metroid game, Metroid Dread, for the Nintendo Switch, developed with MercurySteam.[40] The game is a"
		"\nnew realization of the cancelled Nintendo DS project from the late 2000s.[41] The Metroid series contains gameplay elements from shooter, platformer, and adventure games.[3] The series is notable for its non-linear progression and solitary"
		"\nexploration format where the player only controls Samus Aran, with few or no other characters to interact with. The series has been a 2D side-scroller in all its incarnations until the Metroid Prime series changed the perspective to a first-person"
		"\nperspective, leading to a new first-person shooter element. The player gains items and power-ups for Samus's cybernetic suit primarily through exploration, and occasionally by defeating alien creatures through real-time combat with the suit's arm"
		"\ncannon. Many such upgrades enable further avenues of exploration.[3][42] A recurring upgrade is the Morph Ball, which allows Samus to curl into a ball, roll into tight places and plant bombs.[3]"
		"\nThe original Metroid was influenced by two other major Nintendo franchises: Mario, from which it borrowed extensive areas of platform jumping, and The Legend of Zelda, from which it borrowed non-linear exploration.[3] The game differed in its"
		"\natmosphere of solitude and foreboding.[3] Metroid was also one of the first video games to feature an exploration to the left as well as the right, and backtracking to already explored areas to search for secret items and paths.[4]"
		"\nThe Metroid series has been noted and praised for its unique style of video game music.[3][48][49] Hirokazu 'Hip' Tanaka, composer of the original Metroid, has said he wanted to make a score that made players feel like they were encountering a"
		"\n'living creature' and had no distinction between music and sound effects.[48][50] The only time the main Metroid theme was heard was after Mother Brain is defeated; this is intended to give the player a catharsis. At all other times, no"
		"\nmelodies are present in the game.[50] The composer of Super Metroid, Kenji Yamamoto, came up with some of the games' themes by humming them to himself while riding his motorcycle to work. He was asked to compose the music for Metroid Prime"
		"\nto reinforce the series continuity.[51] Metroid Prime's Dolby Pro Logic II surround sound was mixed by a member of Dolby.[52]"
		"\nDevelopers from Retro Studios noted how the 6 MB memory budget for all sound effects of a level in Metroid Prime was crucial in producing a quality soundtrack, as each sound had to be of high quality to be included.[51] Composer Kenji"
		"\nYamamoto used heavy drums, piano, voiced chants, clangs of pipes, and electric guitar.[52] Metroid Prime 3: Corruption took advantage of the increased RAM in the Wii, allowing for higher-quality audio samples.[51] Kenji Yamamoto, who composed"
		"\nthe music for Super Metroid and the Prime trilogy, copied the musical design of the original Metroid in Metroid Prime 3, by keeping the music and themes dark and scary until the very end, when uplifting music is played during the credits.[51]"
		"\nSamus is a playable character in all five Super Smash Bros. games.[53][54] Super Smash Bros. Brawl, Super Smash Bros. 4 and Super Smash Bros. Ultimate also feature Zero Suit Samus, a version of the heroine using the blue form-fitting suit"
		"\nseen in Zero Mission and the Prime series.[55][56] Ridley makes cameos in Super Smash Bros., where he can be seen flying through the level Zebes, and in Super Smash Bros. Melee both as an unlockable trophy and in the game's opening, where he is"
		"\nfighting Samus at Ceres Space Station.[57] In Super Smash Bros. Brawl, Ridley, in both normal and Meta Ridley forms, appears as a boss character.[58] Due to demand from fans, Ridley was made a playable fighter in Super Smash Bros. Ultimate"
		"\nalongside fellow newcomer Dark Samus. Kraid also appeared in Super Smash Bros. Melee as a stage hazard in Brinstar Depths and unlockable trophy. Various other characters such as Metroids, Mother Brain and Dark Samus appear as either trophies"
		"\nor stickers in the Super Smash Bros. series as well. A number of locations from the Metroid franchise have appeared in Smash titles as battle stages. This includes planet Zebes in the original game, Brinstar and Brinstar Depths in Melee, and"
		"\nFrigate Orpheon and Norfair in Brawl. Many of these stages were carried forward to later titles.[59] Samus has appeared in other Nintendo games such as Super Mario RPG, Tetris (Nintendo Entertainment System version), Tetris DS, Galactic Pinball,"
		"\nKirby Super Star, Kirby's Dream Land 3 and WarioWare.[4][60][61] A Metroid-lookalike enemy, called the Komayto, was encountered by Pit in Kid Icarus for the NES.[4] In Dead or Alive: Dimensions, a fighting game developed by Team Ninja for the"
		"\nNintendo 3DS, one stage is a replica of the arena in which Samus fights Ridley in Metroid: Other M and features both as assist characters;[62] Samus, however, is not featured as a playable character in Dimensions,[63] as Team Ninja's Yosuke"
		"\nHayashi stated in an interview that 'it would be better to let her focus on her job rather than kicking everyone's butt in [Dead or Alive: Dimensions]'.[64] A Wii U launch game Nintendo Land has a minigame based on the series called 'Metroid Blast'";
	}
	
}
//--------------------------------------------------------------
void ofApp::keyReleased(int key)
{
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y)
{
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button)
{
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button)
{
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button)
{
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y)
{
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y)
{
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h)
{
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg)
{
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo)
{
}
